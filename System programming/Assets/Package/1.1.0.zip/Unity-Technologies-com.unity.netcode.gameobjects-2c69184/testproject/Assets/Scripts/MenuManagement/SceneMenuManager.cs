
/// <summary>
/// The scene menu manager that accepts only SceneReference types
/// </summary>
public class SceneMenuManager : MenuManager<SceneReference>
{
}
