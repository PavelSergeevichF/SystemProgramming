using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Netcode.EditorTests")]
