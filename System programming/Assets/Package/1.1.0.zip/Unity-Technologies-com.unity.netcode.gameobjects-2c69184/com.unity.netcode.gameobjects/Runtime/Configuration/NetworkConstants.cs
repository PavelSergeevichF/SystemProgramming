namespace Unity.Netcode
{
    /// <summary>
    /// A static class containing network constants
    /// </summary>
    internal static class NetworkConstants
    {
        internal const string PROTOCOL_VERSION = "15.0.0";
    }
}
